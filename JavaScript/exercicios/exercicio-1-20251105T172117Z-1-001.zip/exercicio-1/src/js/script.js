function calc(){
    //variaveis globais:
   const entrada = document.querySelector('#entrada')
   const valor = entrada.value
   const elPai = document.querySelector('#respPai')
   
   //verificação e validação:
   if(isNaN(valor)  || valor<-99 || valor>99){
    console.error(`Erro: O valor ${valor} está fora do intervalo permitido de (-99 a 99)`)
    window.alert(`Erro: O valor ${valor} está fora do intervalo permitido de (-99 a 99)`)
    return
   }

   //loop de 1 a 10
   for(i=1; i<=10; i++){
    let novoValor = valor*i

    //cria uma nova div
    let novaDiv = document.createElement('div')
    novaDiv.classList.add('respFilho')

    //cria um paragrafo
    let novoParagrafo = document.createElement('p')
    novoParagrafo.textContent = `${valor} x ${i} = ${novoValor}`

    //div>p
    novaDiv.append(novoParagrafo)

    //divPai>divFilho
    elPai.append(novaDiv)

    console.log(elPai)
   }
}